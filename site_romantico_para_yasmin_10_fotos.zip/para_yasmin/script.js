const startDate = new Date(2026, 7, 4); // mês começa em zero: 7 = agosto
const now = new Date();
const days = Math.max(0, Math.floor((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - startDate) / 86400000));
document.getElementById("days").textContent = days.toLocaleString("pt-BR");

const reveal = document.getElementById("secretReveal");
document.querySelectorAll(".secret").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".secret").forEach((b) => b.classList.remove("active"));
    button.classList.add("active");
    reveal.textContent = button.dataset.message;
  });
});

document.getElementById("promiseButton").addEventListener("click", () => {
  const response = document.getElementById("promiseResponse");
  response.textContent = "Então vamos continuar escolhendo cuidar do nosso amor. Um dia de cada vez. ♡";
  response.animate([{opacity:0,transform:"translateY(6px)"},{opacity:1,transform:"translateY(0)"}], {duration:500, easing:"ease-out"});
});

document.getElementById("finalButton").addEventListener("click", () => {
  const message = document.getElementById("finalMessage");
  message.classList.add("show");
  document.getElementById("finalButton").textContent = "surpresa desbloqueada ♡";
  document.getElementById("finalButton").disabled = true;
  message.scrollIntoView({behavior:"smooth",block:"center"});
  burstHearts();
});

function burstHearts() {
  const symbols = ["♡", "♥", "✦"];
  for (let i = 0; i < 14; i++) {
    const item = document.createElement("span");
    item.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    Object.assign(item.style, {
      position:"fixed", left:(10 + Math.random()*80)+"vw", bottom:"-20px",
      zIndex:"30", color: i % 2 ? "#e7a0ad" : "#c0445c",
      fontSize:(12 + Math.random()*18)+"px", pointerEvents:"none",
      transition:"transform 2.2s ease-out, opacity 2.2s ease-out"
    });
    document.body.appendChild(item);
    requestAnimationFrame(() => {
      item.style.transform = `translateY(-${45 + Math.random()*45}vh) rotate(${Math.random()*90-45}deg)`;
      item.style.opacity = "0";
    });
    setTimeout(() => item.remove(), 2300);
  }
}
